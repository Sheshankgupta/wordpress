<?php
/*
 * Block Name: whatwedo
 * Template for custom block author
 */?>

<section class="sec">
			<div class="container">
				<div class="row">
					<div class="col-xxl-10">
						<h2 class="text-uppercase" style="font:12px 'Jost',sans-serif;"><?php the_field('heading_1') ?></h2>
						<h3 class="mb-0"><?php the_field('description_1') ?></h3>
					</div>
				</div>
			</div>
</section>

