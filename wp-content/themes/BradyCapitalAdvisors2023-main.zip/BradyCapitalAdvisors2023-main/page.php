<?php
get_header('others');
?>
<?php the_content(); ?>
<?php
get_footer();
?>